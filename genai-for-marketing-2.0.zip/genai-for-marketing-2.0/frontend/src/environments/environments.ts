// Replace with you configuration for the Firebase Hosting
export const environment = {
    apiUrl: "",
    firebaseConfig: {
        apiKey: "",
        authDomain: "",
        projectId: "",
        storageBucket: "",
        messagingSenderId: "",
        appId: "",
        measurementId: ""
      }
}