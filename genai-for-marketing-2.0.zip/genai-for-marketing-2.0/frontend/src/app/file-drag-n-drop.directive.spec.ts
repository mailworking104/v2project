import { FileDragNDropDirective } from './file-drag-n-drop.directive';

describe('FileDragNDropDirective', () => {
  it('should create an instance', () => {
    const directive = new FileDragNDropDirective();
    expect(directive).toBeTruthy();
  });
});
