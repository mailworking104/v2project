export interface Audience {
    customer_id?: any;
    email?: any;
    city?: any;
    state?: any;
    channel?: any;
    total_purchases?: any;
    total_value?: any;
    total_emails?: any;
    loyalty_score?: any;
    is_media_follower: any;
    last_sign_up_date:any;
    last_purchase_date:any;
    last_activity_date:any;
    cart_total:any;
}